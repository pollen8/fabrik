package com.fusioncharts.exporter.error;

/**
 * Enum for the type of error - "error" and "warning".
 * 
 */
public enum ErrorType {
	ERROR, WARNING;
	@Override
	public String toString() {
		return super.toString();
	}
}